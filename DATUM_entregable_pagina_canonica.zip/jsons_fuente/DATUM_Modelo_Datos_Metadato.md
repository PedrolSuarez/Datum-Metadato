# DATUM — Modelo de Datos del Metadato

> 193 entidades · 1346 atributos · dominios reasignados.


# D0  (30 entidades)


## D01 · Catálogos de datos
- `reference_catalog` 📦
- `reference_category` 📦
- `reference_nature` 📦
- `reference_value` 📦

## Estructura del producto
- `metamodel_domain` 📦
- `physical_catalog` 📦
- `physical_schema` 📦

## Estándares ISO
- `country` 📦
- `country_subdivision` 📦
- `currency` 📦
- `language` 📦
- `unit_of_measure` 📦

## F · Configuración física (Delta)
- `config_pattern` 📦
- `config_pattern_delta_default` 📦
- `delta_property` 📦
- `object_delta_override` 📦

## I · Facetas transversales (versión/aprobación)
- `object_approval` 📦
- `object_version` 📦

## Tipos de datos
- `data_type_domain_composite` 📦
- `data_type_domain_dq_rule` 📦
- `data_type_domain_field` 📦
- `data_type_domain_simple` 📦
- `data_type_domain_ui_control` 📦
- `data_type_mapping` 📦
- `generic_data_type` 📦

## Workflows (patrones)
- `workflow_pattern` 📦
- `workflow_pattern_step` 📦

## i18n
- `object_text` 📦
- `object_type` 📦
- `text_field_kind` 📦

# D1  (5 entidades)


## E · Reglas de negocio
- `business_rule` 📦

## Organización (organigrama real)
- `business_unit` 📦
- `business_unit_role_assignment` 📦

## Procesos
- `business_process` 📦
- `business_process_term` 📦

# D2  (31 entidades)


## A · Entidades y atributos
- `canonical_attribute` 📦
- `canonical_entity` 📦

## A.bis · BK hash / desanonimización
- `canonical_entity_bk_alias` 📦
- `canonical_entity_bk_lookup_config` 📦

## B · Claves e identidad
- `canonical_key` 📦
- `canonical_key_attribute` 📦

## C · Relaciones
- `canonical_relation` 🧩
- `canonical_relation_attribute_map` 🧩
- `canonical_relation_end` 🧩

## D · Restricciones
- `canonical_attribute_constraint` 📦
- `canonical_entity_constraint` 📦
- `canonical_entity_constraint_attribute` 📦

## E · Consumo desde organización (D1→D2)
- `canonical_entity_business_process` 🧩

## F · Versionado del modelo
- `canonical_attribute_version` 🧩
- `canonical_entity_version` 🧩
- `canonical_model_change` 🧩

## G · Aceleradores
- `canonical_accelerator` 🧩

## G · Vistas canónicas / expresión
- `canonical_view` 📦
- `expression` 📦
- `expression_node` 📦
- `expression_operand` 📦
- `function_catalog` 📦

## G2 · Lifecycle
- `lifecycle_phase_approval_rule` 🧩
- `lifecycle_policy` 🧩

## H · Extensibilidad
- `canonical_attribute_attribute` 🧩
- `canonical_entity_attribute` 🧩

## S · Capa semántica (término de negocio)
- `business_term` 📦
- `business_term_canonical_entity` 🧩
- `business_term_related` 📦
- `business_term_synonym` 📦
- `canonical_attribute_business_term` 🧩

# D3  (43 entidades)


## A · Sistemas y conexiones
- `source_connection` 🧩
- `source_connection_credential` 🧩
- `source_connection_token_state` 🧩
- `source_system` 📦

## B · Entidades y atributos
- `source_attribute` 📦
- `source_entity` 📦

## C · Especialización por tipo
- `multi_record` 🧩
- `source_api_endpoint_parameter` 🧩
- `source_api_graphql_query` 🧩
- `source_api_soap_operation` 🧩
- `source_archive_container` 🧩
- `source_entity_api_endpoint` 🧩
- `source_entity_database` 🧩
- `source_entity_excel_workbook` 🧩
- `source_entity_file` 🧩
- `source_entity_stream_topic` 🧩
- `source_entity_webhook` 🧩

## D · Claves y constraints de origen
- `source_key` 📦
- `source_key_attribute` 📦

## D · Golden source y vínculo
- `golden_source` 🧩
- `source_entity_business_term` 🧩
- `source_entity_canonical_entity_hint` 🧩
- `source_entity_relation` 🧩

## E · Captura
- `source_entity_capture_config` 📦
- `source_entity_partition_strategy` 📦

## F · Discovery y drift
- `source_discovery_drift` 🧩
- `source_discovery_run` 🧩

## G · Calidad en origen
- `source_attribute_quality_hint` 🧩

## H · Versionado
- `source_attribute_version` 🧩
- `source_entity_version` 🧩

## J · Discovery completo y profiling
- `discovery_rule` 🧩
- `discovery_rule_evaluation` 🧩
- `source_attribute_detected_type_domain` 🧩
- `source_attribute_profile` 🧩
- `source_discovery_config` 🧩
- `source_discovery_sampling_result` 🧩

## K · Data contracts (UNE)
- `source_data_contract` 📦
- `source_data_contract_sla` 📦

## Runners
- `runner_discover` 🧩
- `runner_ingest_managed` 🧩
- `runner_ingest_streaming` 🧩

## Tipos de datos
- `data_type` 📦
- `technology` 📦

# D4  (24 entidades)


## A · Reglas
- `transformation_rule` 📦
- `transformation_rule_parameter` 📦

## B · Mappings
- `mapping_condition` 🧩
- `mapping_input` 🧩
- `mapping_output` 🧩
- `mapping_parameter_value` 🧩
- `transformation_mapping` 🧩

## C · Pipelines
- `pipeline_dependency` 📦
- `transformation_pipeline` 📦
- `transformation_pipeline_step` 📦

## D · Tipos específicos
- `encryption_config` 📦
- `masking_config` 📦
- `reference_mapping_set` 📦
- `reference_mapping_set_entry` 📦

## E · Vínculo source→canonical
- `source_attribute_canonical_attribute_map` 🧩

## F · Ejecución
- `transformation_run` 📦
- `transformation_run_step` 📦

## G · Versionado SCD2
- `transformation_mapping_version` 🧩
- `transformation_rule_version` 🧩

## H · Artefacto de materialización (DDL)
- `compiled_ddl` 📦

## H · Extensibilidad
- `mapping_attribute` 🧩
- `mapping_attribute_value` 🧩
- `rule_attribute` 🧩
- `rule_attribute_value` 🧩

# D5  (2 entidades)


## Vistas canónicas declarativas
- `impact_analysis` 📦
- `lineage_view_definition` 📦

# D6  (9 entidades)


## B · Dimensiones
- `dimension` 📦

## D · Remediación
- `dq_quarantine_policy` 📦

## ISO 25040 · Definición
- `dq_evaluation_specification` 📦

## ISO · Puentes
- `dq_dimension_to_iso_characteristic` 📦

## UNE Q1 · Definición
- `data_quality_requirement` 📦
- `dq_implementation_plan` 📦

## UNE Q3 · Definición
- `dq_assurance_procedure` 📦
- `dq_audit_plan` 📦
- `dq_certification_criteria` 📦

# D7  (6 entidades)


## A · Hechos acumulativos
- `accumulative_fact` 📦
- `accumulative_fact_dimension` 📦

## C · KPIs
- `kpi` 📦
- `kpi_dependency` 📦

## D · Data Products
- `data_product` 📦
- `data_product_fact` 📦

# D8  (21 entidades)


## B · Roles y RBAC
- `governance_role` 📦

## C · Access Grants
- `data_access_grant` 📦
- `data_access_grant_approval` 📦
- `data_access_grant_condition` 📦
- `effective_permission_cache` 📦

## D · Audit (config)
- `data_access_review` 📦

## E · Bases legales
- `legal_basis` 📦
- `processing_purpose` 📦

## G18 · Sharing interno
- `data_sharing_request` 📦

## G3 · Incidentes
- `incident_type_definition` 📦

## H · Cesiones y encargos
- `data_processing_agreement` 📦
- `data_sharing_agreement` 📦
- `international_data_transfer` 📦

## I · ROPA
- `processing_activity_record` 📦

## J · Políticas ABAC
- `access_policy` 📦
- `access_policy_target` 📦

## K · Facetas genéricas y motor de evaluación (DATUM-49/50)
- `assessment_pattern` 📦
- `assessment_pattern_threshold` 📦
- `assessment_question` 📦
- `object_assessment` 📦
- `object_assessment_answer` 📦

# D9  (8 entidades)


## A · Exposición
- `data_exposure` 📦
- `exposure_consumer` 📦

## B · Config por mecanismo
- `exposure_api_config` 📦
- `exposure_direct_config` 📦
- `exposure_push_config` 📦

## C · Marketplace
- `marketplace_listing` 📦
- `marketplace_request` 📦

## D · Cumplimiento
- `exposure_compliance` 📦

# D10  (11 entidades)


## A · Módulos y pantallas
- `ui_module` 📦
- `ui_screen` 📦
- `ui_screen_breadcrumb_definition` 📦

## B · Permisos UI (RBAC)
- `ui_role_permission` 📦
- `ui_role_permission_set` 📦

## C · Branding e i18n
- `client_branding` 📦

## D · Soporte/Ticketing
- `support_module_config` 📦
- `support_ticket_category` 📦

## E · Motor generativo (DATUM-30)
- `pattern_slot` 📦
- `presentation_pattern` 📦
- `ui_screen_slot_binding` 📦

# D14  (3 entidades)


## Documentación gobernada
- `governed_document` 📦
- `governed_document_link` 📦
- `governed_document_owner` 📦