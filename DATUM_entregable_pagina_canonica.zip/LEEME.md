# Entregable — Página "Modelo canónico" + submodelo D00 (implementación física)

Copiar la carpeta dataplane-app/ SOBRE la app existente, luego `npm run build` y reiniciar.
La entrada "Modelo canónico" aparece en el menú lateral (debajo de "Metadato").

## dataplane-app/ — ficheros a copiar
- src/app/dashboard/canonico/page.tsx ...... página (árbol dominio→subdominio, ER interactivo por subdominio, i18n ES/EN/FR/PT)
- src/components/nav.config.ts ............. entrada de menú "canonico"
- src/i18n/translations.ts ................. label nav.canonico (4 idiomas)
- public/datum_modelo_canonico.json ........ modelo (195 entidades; incluye D00 impl. física)
- public/datum_catalogos.json .............. catálogos (incluye RECORD_STATUS: ACTIVE/INACTIVE)
- public/datum_i18n_d2.json ................ i18n D2

## Submodelo nuevo — D0 / "D00 · Implementación física catálogos"
- storage_layer: code(PK), sort_order — capa lógica (METADATA, LANDING, OPERATIONAL, COMMON, BUSINESS, NEGOCIO, OBSERVABILITY)
- storage_location: code(PK), storage_layer_code(FK), container_path, status_code(FK RECORD_STATUS)
- physical_catalog: code(PK), storage_layer_code(FK), storage_location_code(FK), physical_name, status_code
- physical_schema: physical_catalog_code(FK)+code(PK), physical_name, status_code
Regla: toda entidad del metadato → catálogo=metadata, esquema=su subdominio.

## jsons_fuente/ — para canonizar en /mnt/project/
- DATUM_Modelo_Datos_Metadato.json (+ .md) — estructura
- DATUM_Catalogos.json — catálogos
- DATUM_Carga_Inicial_Metadato.json — SEED (se despliega primero): storage_layer(7), storage_location(4), physical_catalog=metadata, physical_schema por subdominio
- DATUM_i18n_D2.json — i18n D2

## PENDIENTE (próximas sesiones)
- Nombres físicos de 74 esquemas restantes (confirmados: D00→storage, D01→catalog; resto PENDIENTE)
- i18n de dominios/subdominios (ES/EN/FR/PT)
- Registro oficial en control files cuando se ordene
