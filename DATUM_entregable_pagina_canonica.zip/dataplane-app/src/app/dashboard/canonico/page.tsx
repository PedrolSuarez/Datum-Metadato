"use client";

import React, { useState, useMemo, useEffect } from "react";

type Attr = { name: string; tyd: string; mandatory: number|string; pk: number|string; fk_target: string|null; desc?: string; reference_catalog?: string; catalog_ref_metadata_only?: boolean };
type Entity = { subdomain?: string; type?: string; desc?: string; domain?: string; source?: string; i18n?: boolean; status?: string; attributes: Attr[] };
type Model = { _meta?: Record<string,unknown>; entities: Record<string,Entity> };
type Catalog = { dominio?: string; tipo_valor?: string; estado?: string; usado_en?: string[]; desc?: string; values?: Record<string,string>; nota?: string };
type Catalogs = { _meta?: Record<string,unknown>; catalogs: Record<string,Catalog> };
type Texts = { SHORT?: Record<string,string>; SUMMARY?: Record<string,string>; FUNCTIONAL?: Record<string,string> };
type I18nObj = { object_type: string; code: string; texts: Texts };
type I18n = { i18n: Record<string, I18nObj> };

type Lang = "es"|"en"|"fr"|"pt";
const LANGS: Lang[] = ["es","en","fr","pt"];
const DOMAIN_ORDER = ["D0","D1","D2","D3","D4","D5","D6","D7","D8","D9","D10","D14"];

// sha256 igual que el generador python: sha256('datum:'+ot+':'+code)[:16]
async function sha256hex(s: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,"0")).join("").slice(0,16);
}

function domainOf(name: string, e: Entity): string {
  if (e.domain) return e.domain;
  if (name.startsWith("canonical_")||name.startsWith("business_term")||name.startsWith("lifecycle_")) return "D2";
  if (name.startsWith("source_")||name.startsWith("runner_")||name.startsWith("discovery_")||name.startsWith("golden_source")||name==="multi_record") return "D3";
  if (name.startsWith("transformation_")||name.startsWith("mapping_")||name.startsWith("reference_mapping")) return "D4";
  return "D0";
}

export default function CanonicoPage() {
  const [model, setModel] = useState<Model|null>(null);
  const [cats, setCats] = useState<Catalogs|null>(null);
  const [i18n, setI18n] = useState<Record<string,I18nObj>>({});
  const [seed, setSeed] = useState<Record<string, Record<string,unknown>[]>>({});
  const [ridMap, setRidMap] = useState<Record<string,string>>({}); // 'ENT:name' | 'ATTR:full' -> row_id
  const [tab, setTab] = useState<"model"|"catalogs">("model");
  const [openDom, setOpenDom] = useState<string|null>("D2");
  const [openSub, setOpenSub] = useState<Record<string,boolean>>({});
  const [sel, setSel] = useState<string|null>("canonical_entity");
  const [selSub, setSelSub] = useState<{dom:string;sub:string}|null>(null);
  const [lang, setLang] = useState<Lang>("es");
  const [q, setQ] = useState("");

  useEffect(() => {
    fetch("/datum_modelo_canonico.json").then(r=>r.json()).then(setModel).catch(()=>{});
    fetch("/datum_catalogos.json").then(r=>r.json()).then(setCats).catch(()=>{});
    fetch("/datum_i18n_d2.json").then(r=>r.json()).then((d:I18n)=>setI18n(d.i18n||{})).catch(()=>{});
    fetch("/datum_carga_inicial.json").then(r=>r.json()).then((d:{seed?:Record<string,Record<string,unknown>[]>})=>setSeed(d.seed||{})).catch(()=>{});
  }, []);

  // precompute row_ids for entities+attributes once model is loaded
  useEffect(() => {
    if (!model) return;
    (async () => {
      const m: Record<string,string> = {};
      for (const [name,e] of Object.entries(model.entities)) {
        m["ENT:"+name] = await sha256hex("datum:CANONICAL_ENTITY:"+name);
        for (const a of e.attributes) m["ATTR:"+name+"."+a.name] = await sha256hex("datum:CANONICAL_ATTRIBUTE:"+name+"."+a.name);
      }
      setRidMap(m);
    })();
  }, [model]);

  // helpers to resolve i18n texts
  const tEnt = (name: string, kind: keyof Texts): string|undefined => {
    const rid = ridMap["ENT:"+name]; if (!rid) return undefined;
    return i18n[rid]?.texts?.[kind]?.[lang];
  };
  const tAttr = (full: string, kind: keyof Texts): string|undefined => {
    const rid = ridMap["ATTR:"+full]; if (!rid) return undefined;
    return i18n[rid]?.texts?.[kind]?.[lang];
  };

  // SHORT del code (entidad): si hay i18n usa SHORT, si no el code crudo
  const entShort = (name: string) => tEnt(name,"SHORT") || name;

  const byDomain = useMemo(() => {
    if (!model) return {} as Record<string, Record<string,[string,Entity][]>>;
    const m: Record<string, Record<string,[string,Entity][]>> = {};
    const needle = q.trim().toLowerCase();
    for (const [name,e] of Object.entries(model.entities)) {
      const short = (ridMap["ENT:"+name] && i18n[ridMap["ENT:"+name]]?.texts?.SHORT?.[lang]) || "";
      if (needle && !name.toLowerCase().includes(needle) && !short.toLowerCase().includes(needle)) continue;
      const dom = domainOf(name,e);
      const sub = e.subdomain || "—";
      ((m[dom] ||= {})[sub] ||= []).push([name,e]);
    }
    for (const dom of Object.keys(m))
      for (const sub of Object.keys(m[dom]))
        m[dom][sub].sort((a,b)=>a[0].localeCompare(b[0]));
    return m;
  }, [model, q, ridMap, i18n, lang]);

  const domCount = (subs: Record<string,[string,Entity][]>) => Object.values(subs).reduce((n,a)=>n+a.length,0);

  const selEntity = sel && model ? model.entities[sel] : null;

  // ---- Modelo ER de un subdominio ----
  const erData = useMemo(() => {
    if (!selSub || !model) return null;
    const inGroup: [string,Entity][] = Object.entries(model.entities)
      .filter(([n,e])=> domainOf(n,e)===selSub.dom && (e.subdomain||"—")===selSub.sub);
    const names = new Set(inGroup.map(([n])=>n));
    // catálogos genéricos: se ocultan solo si son EXTERNOS al grupo actual (dentro de D01 son el contenido)
    const GENERIC = new Set(["reference_value","reference_catalog","reference_category","reference_nature"]);
    type Rel = { from:string; to:string; field:string; external:boolean; self:boolean };
    const rels: Rel[] = [];
    const boxes = inGroup.map(([n,e])=>{
      const pks = e.attributes.filter(a=>String(a.pk)==="1").map(a=>a.name);
      const fks = e.attributes
        .filter(a=>a.fk_target && !(GENERIC.has(a.fk_target) && !names.has(a.fk_target)))
        .map(a=>({name:a.name,tgt:a.fk_target as string}));
      for (const f of fks) {
        rels.push({ from:n, to:f.tgt, field:f.name, external: !names.has(f.tgt), self: f.tgt===n });
      }
      return { name:n, short: (ridMap["ENT:"+n] && i18n[ridMap["ENT:"+n]]?.texts?.SHORT?.[lang]) || n, pks, fks };
    });
    return { boxes, rels, names };
  }, [selSub, model, ridMap, i18n, lang]);

  const totalEntities = model ? Object.keys(model.entities).length : 0;
  const i18nCount = Object.keys(i18n).length;

  return (
    <div className="cn-wrap">
      <div className="cn-head">
        <div>
          <h1>Modelo canónico del metadato</h1>
          <p className="cn-sub">Fuente única · {totalEntities} entidades · i18n: {i18nCount} textos (D2) · el code se muestra por su nombre traducido</p>
        </div>
        <div className="cn-lang">
          {LANGS.map(l=>(<button key={l} className={lang===l?"on":""} onClick={()=>setLang(l)}>{l.toUpperCase()}</button>))}
        </div>
      </div>

      <div className="cn-tabs">
        <button className={tab==="model"?"on":""} onClick={()=>setTab("model")}>Modelo</button>
        <button className={tab==="catalogs"?"on":""} onClick={()=>setTab("catalogs")}>Catálogos {cats?`(${Object.keys(cats.catalogs).length})`:""}</button>
      </div>

      {tab==="model" && (
        <div className="cn-grid">
          <div className="cn-tree">
            <input className="cn-search" placeholder="Buscar…" value={q} onChange={e=>setQ(e.target.value)} />
            <div className="cn-legend"><span className="cn-legend__ico">🧩</span> entidad derivada (reconstruida de los volcados)</div>
            {DOMAIN_ORDER.filter(d=>byDomain[d] && domCount(byDomain[d])).map(d=>{
              const subs=byDomain[d]; const open=openDom===d||!!q;
              const subNames=Object.keys(subs).sort();
              return (
                <div key={d} className="cn-dom">
                  <div className="cn-dom__h" onClick={()=>setOpenDom(open&&!q?null:d)}>
                    <span className="cn-caret">{open?"▾":"▸"}</span>
                    <span className="cn-dom__name">{d}</span>
                    <span className="cn-count">{domCount(subs)}</span>
                  </div>
                  {open && subNames.map(sub=>{
                    const list=subs[sub];
                    const subKey=d+"::"+sub;
                    const sOpen=openSub[subKey]!==false; // por defecto abierto
                    const single = sub==="—";
                    return (
                      <div key={subKey} className="cn-sub">
                        {!single && (
                          <div className="cn-sub__h">
                            <span className="cn-caret" onClick={()=>setOpenSub(s=>({...s,[subKey]:sOpen?false:true}))}>{sOpen?"▾":"▸"}</span>
                            <span className="cn-sub__name" onClick={()=>{setSelSub({dom:d,sub});setSel(null);}} title="Ver Modelo ER de este subdominio">{sub}</span>
                            <span className="cn-subcount">{list.length}</span>
                            <span className="cn-er-btn" onClick={()=>{setSelSub({dom:d,sub});setSel(null);}} title="Modelo ER">ER</span>
                          </div>
                        )}
                        {(single||sOpen) && (
                          <ul className={"cn-leaves"+(single?" cn-leaves--flat":"")}>
                            {list.map(([name,e])=>{
                              const derived=String(e.source||"").startsWith("derivado");
                              return (
                                <li key={name} className={"cn-leaf"+(sel===name?" sel":"")} onClick={()=>{setSel(name);setSelSub(null);}} title={name}>
                                  <span className="cn-leaf__name">{name}</span>
                                  {e.status==="CUARENTENA" && <span className="cn-badge" title="En cuarentena — pendiente de decisión">🔶</span>}
                                  {derived && <span className="cn-badge" title="Entidad derivada de los volcados (reconstruida), no materializada en el visor original">🧩</span>}
                                </li>
                              );
                            })}
                          </ul>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>

          <div className="cn-detail">
            {selSub && erData ? (
              <ERView dom={selSub.dom} sub={selSub.sub} data={erData} />
            ) : selEntity ? (
              <>
                <div className="cn-detail__h">
                  <span className="cn-tname">{entShort(sel!)}</span>
                  <code className="cn-rawcode">{sel}</code>
                  {String(selEntity.source||"").startsWith("derivado") && <span className="cn-derived" title="Entidad derivada de los volcados">🧩 derivada</span>}
                  {selEntity.status==="CUARENTENA" && <span className="cn-quar" title="En cuarentena — pendiente de decisión">🔶 cuarentena</span>}
                </div>
                {tEnt(sel!,"SUMMARY") && <p className="cn-summary">{tEnt(sel!,"SUMMARY")}</p>}
                {tEnt(sel!,"FUNCTIONAL") && <p className="cn-func">{tEnt(sel!,"FUNCTIONAL")}</p>}
                {!selEntity.i18n && selEntity.desc && <p className="cn-summary">{selEntity.desc}</p>}
                <table className="cn-attrs">
                  <thead><tr><th>Atributo</th><th>Código</th><th>TYD</th><th>Ob</th><th>PK</th><th>FK →</th></tr></thead>
                  <tbody>
                    {selEntity.attributes.map((a,i)=>{
                      const full=sel+"."+a.name;
                      const short=tAttr(full,"SHORT")||a.name;
                      const sum=tAttr(full,"SUMMARY");
                      return (
                        <tr key={i}>
                          <td className="cn-an" title={sum||""}>{short}</td>
                          <td className="cn-rawcol">{a.name}</td>
                          <td className="cn-tyd">{a.tyd}</td>
                          <td className="cn-c">{String(a.mandatory)==="1"?"✔":""}</td>
                          <td className="cn-c">{String(a.pk)==="1"?"🔑":""}</td>
                          <td className="cn-fk">{a.reference_catalog
                            ? <span title={"Valor del catálogo "+a.reference_catalog+" · el catálogo vive en el metadato (no se materializa como columna)"}>▸ {a.reference_catalog}<span className="cn-metaonly">⚙︎</span></span>
                            : (a.fk_target||"")}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                {sel && seed[sel] && seed[sel].length>0 && (
                  <div className="cn-seed">
                    <h4>Datos de carga inicial · {seed[sel].length} fila(s)</h4>
                    <div className="cn-seed-scroll">
                      <table className="cn-attrs">
                        <thead><tr>{Object.keys(seed[sel][0]).filter(k=>!k.startsWith("_")).map(k=>(<th key={k}>{k}</th>))}</tr></thead>
                        <tbody>
                          {seed[sel].map((row,i)=>(
                            <tr key={i}>{Object.keys(seed[sel][0]).filter(k=>!k.startsWith("_")).map(k=>(
                              <td key={k} className="cn-seed-cell">{String(row[k] ?? "")}</td>
                            ))}</tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
                {tAttr(sel+"."+selEntity.attributes[0]?.name,"FUNCTIONAL") && (
                  <div className="cn-attrdetail">
                    <h4>Detalle de atributos</h4>
                    {selEntity.attributes.map((a,i)=>{
                      const full=sel+"."+a.name; const fu=tAttr(full,"FUNCTIONAL"); if(!fu) return null;
                      return (<div key={i} className="cn-ad-row"><span className="cn-ad-name">{tAttr(full,"SHORT")||a.name}</span><span className="cn-ad-text">{fu}</span></div>);
                    })}
                  </div>
                )}
              </>
            ) : <div className="cn-empty">Selecciona una entidad.</div>}
          </div>
        </div>
      )}

      {tab==="catalogs" && cats && (
        <div className="cn-cats">
          {Object.entries(cats.catalogs).map(([code,c])=>(
            <div key={code} className="cn-cat">
              <div className="cn-cat__h">
                <code className="cn-tname">{code}</code>
                <span className={"cn-state cn-state--"+(c.estado||"").toLowerCase()}>{c.estado}</span>
                {c.tipo_valor && <span className="cn-tv">{c.tipo_valor}</span>}
              </div>
              {c.desc && <p className="cn-summary">{c.desc}</p>}
              {c.usado_en?.length ? <div className="cn-used">usado en: {c.usado_en.join(", ")}</div> : null}
              {c.values && Object.keys(c.values).length ? (
                <table className="cn-attrs"><tbody>
                  {Object.entries(c.values).map(([k,v])=>(<tr key={k}><td className="cn-an">{k}</td><td className="cn-ad">{v}</td></tr>))}
                </tbody></table>
              ) : <div className="cn-empty cn-empty--sm">Sin valores {c.nota?`· ${c.nota}`:""}</div>}
              {c.values && Object.keys(c.values).length>0 && c.nota && <div className="cn-note">{c.nota}</div>}
            </div>
          ))}
        </div>
      )}

      <style jsx>{`
        .cn-wrap{padding:22px 26px;height:100%;display:flex;flex-direction:column}
        .cn-head{display:flex;justify-content:space-between;align-items:flex-start}
        .cn-head h1{font-size:20px;margin:0}
        .cn-sub{color:var(--dp-text-dim,#8a94a3);font-size:12px;margin:4px 0 0}
        .cn-lang{display:flex;gap:4px}
        .cn-lang button{background:var(--dp-surface-2,#1a1f27);border:1px solid var(--dp-border,#2a323d);color:var(--dp-text-dim,#8a94a3);border-radius:6px;padding:5px 10px;font-size:11px;cursor:pointer;font-weight:700}
        .cn-lang button.on{background:#4f86c6;color:#fff;border-color:#4f86c6}
        .cn-tabs{display:flex;gap:6px;margin:16px 0;border-bottom:1px solid var(--dp-border,#2a323d)}
        .cn-tabs button{background:none;border:none;color:var(--dp-text-dim,#8a94a3);padding:8px 14px;cursor:pointer;font-size:13px;border-bottom:2px solid transparent}
        .cn-tabs button.on{color:var(--dp-text,#e6e9ee);border-bottom-color:#4f86c6;font-weight:600}
        .cn-grid{display:grid;grid-template-columns:340px 1fr;gap:16px;flex:1;min-height:0}
        .cn-tree{overflow-y:auto;border:1px solid var(--dp-border,#2a323d);border-radius:8px;padding:10px}
        .cn-search{width:100%;background:var(--dp-surface-2,#1a1f27);border:1px solid var(--dp-border,#2a323d);border-radius:6px;padding:7px 10px;color:var(--dp-text,#e6e9ee);font-size:12px;margin-bottom:6px}
        .cn-legend{font-size:10px;color:var(--dp-text-dim,#8a94a3);margin:0 0 10px 2px;display:flex;align-items:center;gap:5px}
        .cn-legend__ico{font-size:11px}
        .cn-dom__h{display:flex;align-items:center;gap:8px;padding:6px 4px;cursor:pointer}
        .cn-caret{color:var(--dp-text-dim,#8a94a3);font-size:10px;width:12px}
        .cn-dom__name{font-weight:700;font-size:13px}
        .cn-count{margin-left:auto;font-size:10px;background:var(--dp-surface-2,#1a1f27);border-radius:10px;padding:1px 8px;color:var(--dp-text-dim,#8a94a3)}
        .cn-leaves{list-style:none;margin:2px 0 8px;padding:0 0 0 20px}
        .cn-leaves--flat{padding-left:20px}
        .cn-sub{margin:0 0 2px}
        .cn-sub__h{display:flex;align-items:center;gap:6px;padding:4px 4px 4px 18px;cursor:pointer}
        .cn-sub__name{font-size:11px;font-weight:600;color:#9fb2c8;text-transform:none}
        .cn-subcount{margin-left:auto;font-size:9px;color:var(--dp-text-dim,#8a94a3);background:var(--dp-surface-2,#1a1f27);border-radius:10px;padding:1px 6px}
        .cn-sub .cn-leaves{padding-left:34px}
        .cn-leaf{display:flex;align-items:center;gap:6px;padding:4px 8px;border-radius:5px;cursor:pointer;font-size:12px;color:var(--dp-text,#cdd3db)}
        .cn-leaf:hover{background:var(--dp-surface-2,#1a1f27)}
        .cn-leaf.sel{background:rgba(79,134,198,.18);color:#fff}
        .cn-leaf__name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .cn-badge{font-size:10px;margin-left:auto}
        .cn-detail{overflow-y:auto;border:1px solid var(--dp-border,#2a323d);border-radius:8px;padding:18px}
        .cn-detail__h{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
        .cn-tname{font-size:16px;font-weight:700;color:var(--dp-text,#e6e9ee)}
        .cn-rawcode{font-size:11px;color:#8a94a3;font-family:ui-monospace,Menlo,monospace;background:var(--dp-surface-2,#1a1f27);padding:2px 7px;border-radius:5px}
        .cn-i18n{font-size:10px;color:#2dd4bf}
        .cn-derived{font-size:10px;color:#fbbf24}
        .cn-quar{font-size:10px;color:#fb923c;border:1px solid #7c3f1d;border-radius:4px;padding:1px 6px}
        .cn-summary{font-size:13px;color:var(--dp-text,#dde2e8);margin:12px 0 6px;line-height:1.5;font-weight:500}
        .cn-func{font-size:12px;color:var(--dp-text-dim,#aab2bd);margin:0 0 14px;line-height:1.6}
        .cn-attrs{width:100%;border-collapse:collapse;font-size:12px}
        .cn-attrs th{text-align:left;color:var(--dp-text-dim,#8a94a3);font-size:10px;text-transform:uppercase;letter-spacing:.4px;padding:6px 8px;border-bottom:1px solid var(--dp-border,#2a323d)}
        .cn-attrs td{padding:6px 8px;border-bottom:1px solid rgba(42,50,61,.4);vertical-align:top}
        .cn-an{color:#e6e9ee;font-weight:500}
        .cn-rawcol{font-family:ui-monospace,Menlo,monospace;color:#8a94a3;font-size:11px;white-space:nowrap}
        .cn-tyd{font-family:ui-monospace,Menlo,monospace;color:#8a94a3;font-size:11px;white-space:nowrap}
        .cn-c{text-align:center}
        .cn-fk{font-family:ui-monospace,Menlo,monospace;color:#2dd4bf;font-size:11px;white-space:nowrap}
        .cn-metaonly{color:#8a94a3;margin-left:4px;font-size:10px}
        .cn-ad{color:var(--dp-text-dim,#aab2bd)}
        .cn-attrdetail{margin-top:20px;border-top:1px solid var(--dp-border,#2a323d);padding-top:14px}
        .cn-attrdetail h4{font-size:12px;color:var(--dp-text-dim,#8a94a3);text-transform:uppercase;letter-spacing:.4px;margin:0 0 10px}
        .cn-seed{margin-top:20px;border-top:1px solid var(--dp-border,#2a323d);padding-top:14px}
        .cn-seed h4{font-size:12px;color:#2dd4bf;text-transform:uppercase;letter-spacing:.4px;margin:0 0 10px}
        .cn-seed-scroll{overflow-x:auto}
        .cn-seed-cell{font-family:ui-monospace,Menlo,monospace;font-size:11px;color:#cdd3db;white-space:nowrap}
        .cn-ad-row{display:grid;grid-template-columns:160px 1fr;gap:12px;padding:7px 0;border-bottom:1px solid rgba(42,50,61,.3)}
        .cn-ad-name{font-weight:600;font-size:12px;color:#cdd3db}
        .cn-ad-text{font-size:12px;color:var(--dp-text-dim,#aab2bd);line-height:1.5}
        .cn-empty{color:var(--dp-text-dim,#8a94a3);padding:40px;text-align:center;font-size:13px}
        .cn-empty--sm{padding:10px;text-align:left;font-size:11px}
        .cn-cats{overflow-y:auto;display:flex;flex-direction:column;gap:14px;flex:1;min-height:0}
        .cn-cat{border:1px solid var(--dp-border,#2a323d);border-radius:8px;padding:14px 16px}
        .cn-cat__h{display:flex;align-items:center;gap:10px}
        .cn-state{font-size:10px;padding:2px 8px;border-radius:5px;font-weight:700}
        .cn-state--confirmado{background:rgba(34,197,94,.15);color:#4ade80}
        .cn-state--pendiente{background:rgba(245,158,11,.15);color:#fbbf24}
        .cn-state--cuarentena{background:rgba(239,68,68,.15);color:#f87171}
        .cn-tv{font-size:10px;color:var(--dp-text-dim,#8a94a3)}
        .cn-used{font-size:11px;color:#7fa8d8;font-family:ui-monospace,Menlo,monospace;margin:4px 0 8px}
        .cn-note{font-size:11px;color:#fbbf24;margin-top:8px}
        .cn-er-btn{font-size:9px;font-weight:700;color:#4f86c6;border:1px solid #33547d;border-radius:4px;padding:1px 5px;cursor:pointer;margin-left:6px}
        .cn-er-btn:hover{background:rgba(79,134,198,.2)}
        .cn-sub__name{cursor:pointer}
      `}</style>
    </div>
  );
}

// ===== Modelo ER de un subdominio (interactivo: drag + zoom/pan + persistencia) =====
type ERBox = { name:string; short:string; pks:string[]; fks:{name:string;tgt:string}[] };
type ERRel = { from:string; to:string; field:string; external:boolean; self:boolean };
type ERDatum = { boxes:ERBox[]; rels:ERRel[]; names:Set<string> };

function ERView({ dom, sub, data }: { dom:string; sub:string; data:ERDatum }) {
  const { boxes, rels } = data;
  const BW=180;
  const boxH = (b:ERBox)=> 24 + (b.pks.length+b.fks.length)*15 + 6;
  const storeKey = `datum-er-pos:${dom}:${sub}`;

  // posiciones (persistentes)
  const initPos = () => {
    try { const raw = window.localStorage.getItem(storeKey); if(raw) return JSON.parse(raw); } catch {}
    const p: Record<string,{x:number;y:number}> = {};
    const cols = Math.max(1, Math.min(3, Math.ceil(Math.sqrt(boxes.length))));
    boxes.forEach((b,i)=>{ p[b.name]={ x:30+(i%cols)*240, y:30+Math.floor(i/cols)*180 }; });
    return p;
  };
  const [pos, setPos] = React.useState<Record<string,{x:number;y:number}>>(initPos);
  React.useEffect(()=>{ setPos(initPos()); /* eslint-disable-next-line */ }, [dom, sub]);
  React.useEffect(()=>{ try{ window.localStorage.setItem(storeKey, JSON.stringify(pos)); }catch{} }, [pos, storeKey]);

  // zoom / pan
  const [view, setView] = React.useState({ z:1, tx:0, ty:0 });
  React.useEffect(()=>{ setView({z:1,tx:0,ty:0}); }, [dom, sub]);

  const svgRef = React.useRef<SVGSVGElement|null>(null);
  const drag = React.useRef<{mode:"box"|"pan"|null; name?:string; sx:number; sy:number; ox:number; oy:number}>({mode:null,sx:0,sy:0,ox:0,oy:0});

  const onDownBox = (e:React.MouseEvent, name:string) => {
    e.stopPropagation();
    drag.current={mode:"box",name,sx:e.clientX,sy:e.clientY,ox:pos[name].x,oy:pos[name].y};
  };
  const onDownBg = (e:React.MouseEvent) => {
    drag.current={mode:"pan",sx:e.clientX,sy:e.clientY,ox:view.tx,oy:view.ty};
  };
  const onMove = (e:React.MouseEvent) => {
    const d=drag.current; if(!d.mode) return;
    const dx=(e.clientX-d.sx)/view.z, dy=(e.clientY-d.sy)/view.z;
    if(d.mode==="box" && d.name){ setPos(p=>({...p,[d.name!]:{x:d.ox+dx,y:d.oy+dy}})); }
    else if(d.mode==="pan"){ setView(v=>({...v,tx:d.ox+(e.clientX-d.sx),ty:d.oy+(e.clientY-d.sy)})); }
  };
  const onUp = () => { drag.current.mode=null; };
  const onWheel = (e:React.WheelEvent) => {
    e.preventDefault();
    const factor = e.deltaY<0 ? 1.1 : 1/1.1;
    setView(v=>({...v, z: Math.min(2.5, Math.max(0.3, v.z*factor))}));
  };
  const reset = () => {
    try{ window.localStorage.removeItem(storeKey); }catch{}
    setView({z:1,tx:0,ty:0});
    const p: Record<string,{x:number;y:number}> = {};
    const cols = Math.max(1, Math.min(3, Math.ceil(Math.sqrt(boxes.length))));
    boxes.forEach((b,i)=>{ p[b.name]={ x:30+(i%cols)*240, y:30+Math.floor(i/cols)*180 }; });
    setPos(p);
  };

  // anclas: borde de la caja hacia el objetivo (línea centro-centro recortada al borde)
  const center = (n:string) => { const p=pos[n]; const b=boxes.find(x=>x.name===n); if(!p||!b) return null; return {x:p.x+BW/2, y:p.y+boxH(b)/2, w:BW, h:boxH(b), px:p.x, py:p.y}; };
  const edgePoint = (from:{x:number;y:number;w:number;h:number;px:number;py:number}, to:{x:number;y:number}) => {
    const dx=to.x-from.x, dy=to.y-from.y; if(dx===0&&dy===0) return {x:from.x,y:from.y};
    const hw=from.w/2, hh=from.h/2;
    const sx = dx!==0 ? hw/Math.abs(dx) : Infinity;
    const sy = dy!==0 ? hh/Math.abs(dy) : Infinity;
    const s = Math.min(sx,sy);
    return { x: from.x+dx*s, y: from.y+dy*s };
  };

  // multiples FK entre mismas cajas: offset perpendicular por índice
  const pairIdx: Record<string,number> = {};
  const pairTot: Record<string,number> = {};
  rels.forEach(r=>{ const k=r.from+"|"+r.to; pairTot[k]=(pairTot[k]||0)+1; });

  return (
    <div className="er-wrap">
      <div className="er-head">
        <span className="er-dom">{dom}</span>
        <h3>{sub}</h3>
        <span className="er-legend"><i className="er-l-int"/>interna <i className="er-l-ext"/>externa <span className="er-hint">· arrastra cajas · rueda=zoom · fondo=pan</span></span>
        <button className="er-reset" onClick={reset}>Reordenar</button>
      </div>
      <div className="er-canvas">
        <svg ref={svgRef} className="er-svg"
             onMouseDown={onDownBg} onMouseMove={onMove} onMouseUp={onUp} onMouseLeave={onUp} onWheel={onWheel}>
          <defs>
            <marker id="arw" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">
              <path d="M0,0 L9,4.5 L0,9 Z" fill="#5b6b7f"/>
            </marker>
            <marker id="arwx" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">
              <path d="M0,0 L9,4.5 L0,9 Z" fill="#8a763f"/>
            </marker>
          </defs>
          <g transform={`translate(${view.tx},${view.ty}) scale(${view.z})`}>
            {rels.map((r,i)=>{
              const cf=center(r.from); if(!cf) return null;
              const k=r.from+"|"+r.to;
              const idx=(pairIdx[k]=(pairIdx[k]??-1)+1); const tot=pairTot[k];
              const off=(idx-(tot-1)/2)*10; // separación de líneas paralelas
              if(r.self){
                // bucle propio arriba-derecha
                const x=cf.px+cf.w, y=cf.py+18+idx*12;
                return <g key={i}>
                  <path d={`M${x},${y} q26,-4 26,10 q0,14 -20,12`} fill="none" stroke="#5b6b7f" strokeWidth="1.2" markerEnd="url(#arw)"/>
                  <text x={x+30} y={y-2} className="er-flbl">{r.field}</text>
                </g>;
              }
              if(r.external){
                const x=cf.px+cf.w, y=cf.y+off;
                return <g key={i}>
                  <line x1={x} y1={y} x2={x+30} y2={y} stroke="#8a763f" strokeWidth="1.3" strokeDasharray="4 3" markerEnd="url(#arwx)"/>
                  <text x={x+34} y={y+3} className="er-ext-lbl">{r.to}<tspan className="er-flbl2"> ({r.field})</tspan></text>
                </g>;
              }
              const ct=center(r.to); if(!ct) return null;
              // punto medio con offset perpendicular para separar múltiples
              const a=edgePoint(cf,ct), b=edgePoint(ct,cf);
              const mx=(a.x+b.x)/2, my=(a.y+b.y)/2;
              const nx=-(b.y-a.y), ny=(b.x-a.x); const nl=Math.hypot(nx,ny)||1;
              const mmx=mx+ (nx/nl)*off, mmy=my+(ny/nl)*off;
              return <g key={i}>
                <path d={`M${a.x},${a.y} Q${mmx},${mmy} ${b.x},${b.y}`} fill="none" stroke="#5b6b7f" strokeWidth="1.3" markerEnd="url(#arw)"/>
                <text x={mmx} y={mmy-2} className="er-flbl" textAnchor="middle">{r.field}</text>
              </g>;
            })}
            {boxes.map(b=>{
              const p=pos[b.name]; if(!p) return null; let y=p.y+20;
              return (
                <g key={b.name} onMouseDown={(e)=>onDownBox(e,b.name)} style={{cursor:"grab"}}>
                  <rect x={p.x} y={p.y} width={BW} height={boxH(b)} rx="6" className="er-box"/>
                  <rect x={p.x} y={p.y} width={BW} height="20" rx="6" className="er-box-h"/>
                  <text x={p.x+8} y={p.y+14} className="er-box-title">{b.name}</text>
                  {b.pks.map((pk,i)=>(<text key={"p"+i} x={p.x+10} y={(y+=15)-3} className="er-pk">🔑 {pk}</text>))}
                  {b.fks.map((fk,i)=>(<text key={"f"+i} x={p.x+10} y={(y+=15)-3} className="er-fk">↗ {fk.name}</text>))}
                </g>
              );
            })}
          </g>
        </svg>
      </div>
      <style jsx>{`
        .er-wrap{display:flex;flex-direction:column;height:100%}
        .er-head{display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap}
        .er-dom{font-size:11px;font-weight:700;background:rgba(79,134,198,.18);color:#7fa8d8;padding:2px 8px;border-radius:5px}
        .er-head h3{margin:0;font-size:15px;color:var(--dp-text,#e6e9ee)}
        .er-legend{margin-left:auto;font-size:10px;color:var(--dp-text-dim,#8a94a3);display:flex;align-items:center;gap:6px}
        .er-legend i{display:inline-block;width:16px;height:0;border-top:2px solid #5b6b7f;margin-right:2px}
        .er-legend .er-l-ext{border-top:2px dashed #8a763f}
        .er-hint{color:#5b6b7f}
        .er-reset{font-size:10px;font-weight:700;color:#7fa8d8;background:var(--dp-surface-2,#1a1f27);border:1px solid #33547d;border-radius:5px;padding:3px 9px;cursor:pointer}
        .er-canvas{flex:1;min-height:0;border:1px solid var(--dp-border,#2a323d);border-radius:8px;background:rgba(0,0,0,.15);overflow:hidden}
        .er-svg{display:block;width:100%;height:100%;min-height:520px;user-select:none}
      `}</style>
      <style jsx global>{`
        .er-box{fill:#161b22;stroke:#2a323d;stroke-width:1}
        .er-box-h{fill:#233046;stroke:#2a323d;stroke-width:1}
        .er-box-title{fill:#e6e9ee;font:600 11px ui-monospace,Menlo,monospace}
        .er-pk{fill:#e8c37a;font:10px ui-monospace,Menlo,monospace}
        .er-fk{fill:#2dd4bf;font:10px ui-monospace,Menlo,monospace}
        .er-flbl{fill:#8a94a3;font:9px ui-monospace,Menlo,monospace}
        .er-flbl2{fill:#8a763f}
        .er-ext-lbl{fill:#b39a5f;font:9px ui-monospace,Menlo,monospace}
      `}</style>
    </div>
  );
}
