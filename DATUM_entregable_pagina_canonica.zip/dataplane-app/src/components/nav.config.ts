// Configuración del menú lateral. labelKey resuelve contra el diccionario i18n.
export type NavItem = { key: string; labelKey: string; href: string; icon: string };
export type NavGroup = { titleKey: string; items: NavItem[] };

export const navGroups: NavGroup[] = [
  {
    titleKey: "nav.group_dataplane",
    items: [
      { key: "overview", labelKey: "nav.overview", href: "/dashboard", icon: "▦" },
      { key: "metadata", labelKey: "nav.metadata", href: "/dashboard/metadato", icon: "❖" },
      { key: "canonico", labelKey: "nav.canonico", href: "/dashboard/canonico", icon: "◆" },
      { key: "topology", labelKey: "nav.topology", href: "/dashboard/topologia", icon: "◇" },
      { key: "business", labelKey: "nav.business", href: "/dashboard/negocio", icon: "◈" },
      { key: "dataproducts", labelKey: "nav.dataproducts", href: "/dashboard/dataproducts", icon: "📦" },
      { key: "discovery", labelKey: "nav.discovery", href: "/dashboard/descubrimiento", icon: "⊚" },
    ],
  },
  {
    titleKey: "nav.group_operation",
    items: [
      { key: "ingestion", labelKey: "nav.ingestion", href: "/dashboard/ingesta", icon: "↓" },
      { key: "sources", labelKey: "nav.sources", href: "/dashboard/fuentes", icon: "🗄️" },
      { key: "transforms", labelKey: "nav.transforms", href: "/dashboard/transformaciones", icon: "⚙" },
      { key: "workflows", labelKey: "nav.workflows", href: "/dashboard/workflows", icon: "⊞" },
      { key: "observability", labelKey: "nav.observability", href: "/dashboard/observabilidad", icon: "◉" },
      { key: "processing", labelKey: "nav.processing", href: "/dashboard/procesamiento", icon: "⚙" },
      { key: "quality", labelKey: "nav.quality", href: "/dashboard/calidad", icon: "✓" },
      { key: "lineage", labelKey: "nav.lineage", href: "/dashboard/linaje", icon: "⇄" },
    ],
  },
  {
    titleKey: "nav.group_governance",
    items: [
      { key: "policies", labelKey: "nav.policies", href: "/dashboard/politicas", icon: "§" },
      { key: "runners", labelKey: "nav.runners", href: "/dashboard/runners", icon: "▷" },
    ],
  },
];
